# Cognition Shift Study — Render-ready

This project turns the original single-file prototype into a Flask web app with:

- the original pre-test → 10-minute AI conversation → post-test flow;
- server-side Claude API calls (the API key is never put in browser code);
- anonymous participant identifier/session UUID;
- PostgreSQL storage of completed sessions and full transcripts;
- CSV export for the researcher;
- Render Blueprint configuration.

## Deploy on Render

1. Put this folder in a GitHub repository.
2. In Render, choose **New → Blueprint** and connect the repository.
3. Render will create the web service and PostgreSQL database from `render.yaml`.
4. In the web service's Environment settings, add your Anthropic API key to `ANTHROPIC_API_KEY`.
5. Deploy.
6. Open the generated `onrender.com` URL.

The researcher export endpoint is:

`https://YOUR-SERVICE.onrender.com/admin/export.csv`

It uses HTTP Basic Authentication: username `admin`, password = the generated `ADMIN_PASSWORD` shown in Render Environment settings. Keep that password private.

## Local run

Set `DATABASE_URL` to a PostgreSQL connection string and `ANTHROPIC_API_KEY`, then:

```bash
pip install -r requirements.txt
python app.py
```

## Important research note

The study currently contains the scenario, evidence bank, legal-fact wording, and staged AI prompt from the supplied prototype. Before collecting real participants, the researcher should pilot the full study and confirm that the AI model/version and prompt are acceptable for the approved research protocol. If your ethics/IRB approval specifies a particular model, prompt, data retention period, or participant information/consent wording, those should take precedence.
