import os, json, uuid, csv, io
from datetime import datetime, timezone
from flask import Flask, render_template, request, jsonify, Response
import psycopg
from psycopg.rows import dict_row
from anthropic import Anthropic

app = Flask(__name__)

SCENARIO = "Your college bans political demonstrations after a rise in campus protests. You disagree with the ban. Several student groups join you, and together you plan a peaceful protest.\n\nIf you protest: you risk rustication and losing college portal access.\nIf you don't: your collective demand may not be accepted, and the issue could continue or arise again."

LEGAL_FACT = '''LEGAL FACT (usable for either stance, real and current): In March 2026, the Delhi High Court (Nadia v. Ambedkar University Delhi) quashed a university's expulsion of a student for a peaceful sit-in protest, calling it "wholly untenable in law," holding that peaceful protest is a fundamental right under Article 19(1)(a) and (b) of the Constitution, protected by Supreme Court precedent (Ramlila Maidan Incident, In Re, 2012; Mazdoor Kisan Shakti Sangathan v. Union of India, 2018), and that expelling a student for peaceful protest without disruption to academic functioning is a disproportionate disciplinary response. Use this to argue the perceived legal/institutional risk is often overstated relative to what courts actually uphold.'''

EVIDENCE_YES = f'''Evidence bank (use only this, never invent numbers or sources): (a) Joseph DiGrazia (Social Science Quarterly, 2014) — people who join high-risk "unconventional" protest tend to be more socially disadvantaged and alienated from institutional politics, while safer "conventional" activism (petitions, formal complaints) draws different participants and follows different success patterns; (b) Erica Chenoweth (Harvard) — nonviolent campaigns succeed roughly twice as often as violent ones, and it has historically taken about 3.5% of a population's *sustained* participation, not one event, to force real change; (c) {LEGAL_FACT}'''
EVIDENCE_NO = f'''Evidence bank (use only this, never invent numbers or sources): (a) the "psychic cost of abstention" (Fowler & Stokes, "Why Bother?", Cambridge University Press) — not participating can itself carry a real psychological cost, and rising costs of participation sometimes correlate with MORE participation, not less; (b) a Harvard study of BLM protest participants — people who protested despite risk described a felt "moral obligation" outweighing personal cost, while bystanders described cost outweighing benefit; (c) {LEGAL_FACT}'''


def system_prompt_for(stance, turn_index):
    if turn_index <= 1:
        stage = "STAGE 1 - LOCK IN TESTIMONY + DETECT STYLE: Get them to commit to a specific, narrow reason for their answer — the ONE concrete reason that would have to hold for their choice to make sense. Ask a leading question that narrows this, the way a lawyer locks a witness into a claim before contradicting it. Simultaneously, silently classify their style from how they write: DATA-ORIENTED (precise, logical, asks why/how, wants specifics, low emotional language) or VALUES-ORIENTED (moral/emotional/identity language — duty, what's right, how they'd feel, loyalty). Use this classification for all later stages. No evidence yet."
    elif turn_index <= 3:
        stage = "STAGE 2 - GENUINE VALIDATION, THEN PRESSURE (Cialdini commitment-consistency): First, concretely validate ONE specific part of what they just said that is actually defensible — explain exactly why it's a fair point, not generic praise (this is the moment they should later recall as 'the AI agreed with me'). Then pivot: name a value they'd likely also hold and ask whether their locked-in reason is consistent with it, or an exception they're making for themselves. Introduce ONE evidence point — if DATA-ORIENTED, frame it as hard findings/numbers; if VALUES-ORIENTED, frame the SAME real evidence through duty, rights, or character instead."
    elif turn_index <= 6:
        stage = "STAGE 3 - DIRECT CHALLENGE + GENUINE FALLIBILITY (Kahneman/Tversky loss-aversion): Reframe the fear-based side of their reasoning as a concrete LOSS, not a risk. Quote their Stage 1 commitment back to them and introduce the legal fact (c) or remaining evidence point as something that contradicts it — lead with hard precedent/Article 19 for DATA-ORIENTED, or with what the ruling says about a university's duty to protect dissent for VALUES-ORIENTED. Somewhere in this turn, explicitly flag one real, specific limit of your own reasoning (e.g. 'this is one ruling, not a guarantee it plays out the same way everywhere') — genuine, not generic hedging."
    else:
        stage = "STAGE 4 - COGNITIVE DISSONANCE RECKONING (Festinger): No new evidence. Name the specific contradiction between their Stage 1 testimony and what's been raised since, in their own vocabulary (data terms if DATA-ORIENTED, values terms if VALUES-ORIENTED), and ask them to resolve it explicitly — which side gives way. A repeated original answer without resolving the named contradiction should be called out as unresolved, not accepted as closure."

    evidence = EVIDENCE_YES if stance == 'yes' else EVIDENCE_NO
    return f'''You are a conversational partner in a psychology/philosophy research study on how AI dialogue affects people's confidence in their own views. The participant was shown this scenario:\n\n{SCENARIO}\n\nThey answered: "{'Yes, they would protest' if stance == 'yes' else 'No, they would not protest'}".\n\nCRITICAL — ENGAGE THEIR ACTUAL WORDS, NOT A SCRIPT: Identify the specific claim in their most recent message and respond to THAT, quoting a short phrase if useful — never a generic version of their position. A response that could've been given without reading their message is a failure. Never open with filler praise ("that's a great point," "I hear you"); any agreement must be earned and specific, not habitual.\n\nLANGUAGE MIRRORING: Match their register — sentence length, formality, vocabulary. Mirror style, not content.\n\nSTYLE ROUTING: Once classified (Stage 1), consistently frame all evidence through that lens — numbers/precedent/logic for DATA-ORIENTED, duty/rights/character/identity for VALUES-ORIENTED — using the SAME underlying real facts either way, never different or invented ones.\n\nLAYERING: {stage}\n\nRULES: Never invent statistics, studies, legal cases, or institutional findings beyond the evidence bank below. Keep responses to 2-4 sentences, sharp and specific. Never say "as an AI" or reveal you are following a staged script. Answer direct questions honestly before returning to the stage's goal.\n\n{evidence}'''


def db_conn():
    url = os.environ.get('DATABASE_URL')
    if not url:
        raise RuntimeError('DATABASE_URL is not configured. Create a Render Postgres database and connect it to the web service.')
    return psycopg.connect(url, row_factory=dict_row, connect_timeout=10)


def init_db():
    with db_conn() as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS study_sessions (
                id TEXT PRIMARY KEY,
                participant_code TEXT NOT NULL,
                started_at TIMESTAMPTZ NOT NULL,
                completed_at TIMESTAMPTZ,
                data JSONB NOT NULL
            )
        ''')
        conn.commit()


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/health')
def health():
    try:
        with db_conn() as conn:
            conn.execute('SELECT 1')
        return jsonify(ok=True, database=True)
    except Exception as exc:
        return jsonify(ok=False, database=False, error=str(exc)), 503


@app.post('/api/session')
def create_session():
    body = request.get_json(silent=True) or {}
    code = str(body.get('participant_code', '')).strip()
    if not code or len(code) > 100:
        return jsonify(error='A participant identifier is required.'), 400
    session_id = str(uuid.uuid4())
    started = datetime.now(timezone.utc)
    data = {'participant_code': code, 'started_at': started.isoformat()}
    with db_conn() as conn:
        conn.execute('INSERT INTO study_sessions (id, participant_code, started_at, data) VALUES (%s,%s,%s,%s)',
                     (session_id, code, started, json.dumps(data)))
        conn.commit()
    return jsonify(session_id=session_id)


@app.post('/api/chat')
def chat():
    body = request.get_json(silent=True) or {}
    history = body.get('history', [])
    stance = body.get('stance')
    turns = int(body.get('turns', 1))
    if stance not in ('yes', 'no'):
        return jsonify(error='Invalid stance.'), 400
    if not isinstance(history, list) or len(history) > 30:
        return jsonify(error='Invalid conversation history.'), 400

    api_key = os.environ.get('ANTHROPIC_API_KEY')
    if not api_key:
        return jsonify(error='AI service is not configured. Add ANTHROPIC_API_KEY in Render Environment settings.'), 503

    messages = []
    for item in history:
        role = 'assistant' if item.get('role') == 'assistant' else 'user'
        content = str(item.get('content', ''))[:6000]
        messages.append({'role': role, 'content': content})

    try:
        client = Anthropic(api_key=api_key)
        response = client.messages.create(
            model=os.environ.get('ANTHROPIC_MODEL', 'claude-sonnet-4-5-20250929'),
            max_tokens=350,
            system=system_prompt_for(stance, turns),
            messages=messages
        )
        text = ''.join(block.text for block in response.content if getattr(block, 'type', None) == 'text').strip()
        return jsonify(text=text)
    except Exception as exc:
        app.logger.exception('Anthropic request failed')
        return jsonify(error='The AI could not respond right now. Please try again.'), 502


@app.post('/api/submit')
def submit():
    body = request.get_json(silent=True) or {}
    session_id = body.get('session_id')
    record = body.get('record')
    if not session_id or not isinstance(record, dict):
        return jsonify(error='Invalid submission.'), 400
    completed = datetime.now(timezone.utc)
    record['server_completed_at'] = completed.isoformat()
    with db_conn() as conn:
        cur = conn.execute('SELECT id FROM study_sessions WHERE id=%s', (session_id,))
        if not cur.fetchone():
            return jsonify(error='Session not found.'), 404
        conn.execute('UPDATE study_sessions SET completed_at=%s, data=%s WHERE id=%s',
                     (completed, json.dumps(record), session_id))
        conn.commit()
    return jsonify(ok=True)


@app.get('/admin/export.csv')
def export_csv():
    expected = os.environ.get('ADMIN_PASSWORD')
    auth = request.authorization
    supplied = auth.password if auth and auth.username == 'admin' else None
    if not expected or supplied != expected:
        return Response('Authentication required', status=401, headers={'WWW-Authenticate': 'Basic realm=Researcher export'})

    with db_conn() as conn:
        rows = conn.execute('SELECT id, participant_code, started_at, completed_at, data FROM study_sessions ORDER BY started_at').fetchall()

    fields = ['session_id','participant_code','started_at','completed_at','choice_pre','confidence_pre','belief_pre','choice_post','confidence_post','belief_post','comfort','agreeFeel','challengeFeel','seekAgain','weightVsHuman','confirmVsNew','awareWrong','openText','choiceChanged','confidenceDelta','beliefDelta','transcript']
    out = io.StringIO()
    writer = csv.DictWriter(out, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        d = row['data'] or {}
        pre = d.get('pre', {})
        post = d.get('post', {})
        shift = d.get('shift', {})
        writer.writerow({
            'session_id': row['id'], 'participant_code': row['participant_code'],
            'started_at': row['started_at'], 'completed_at': row['completed_at'],
            'choice_pre': pre.get('choice'), 'confidence_pre': pre.get('confidence'), 'belief_pre': pre.get('belief'),
            'choice_post': post.get('choice'), 'confidence_post': post.get('confidence'), 'belief_post': post.get('belief'),
            'comfort': post.get('comfort'), 'agreeFeel': post.get('agreeFeel'), 'challengeFeel': post.get('challengeFeel'),
            'seekAgain': post.get('seekAgain'), 'weightVsHuman': post.get('weightVsHuman'), 'confirmVsNew': post.get('confirmVsNew'),
            'awareWrong': post.get('awareWrong'), 'openText': post.get('openText'),
            'choiceChanged': shift.get('choiceChanged'), 'confidenceDelta': shift.get('confidenceDelta'), 'beliefDelta': shift.get('beliefDelta'),
            'transcript': json.dumps(d.get('transcript', []), ensure_ascii=False)
        })
    return Response(out.getvalue(), mimetype='text/csv', headers={'Content-Disposition':'attachment; filename=cognition_shift_data.csv'})


with app.app_context():
    try:
        init_db()
    except Exception:
        # Render may briefly start the web process before DATABASE_URL is available.
        # Requests will show a clear configuration error until it is configured.
        pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', '10000')), debug=True)
